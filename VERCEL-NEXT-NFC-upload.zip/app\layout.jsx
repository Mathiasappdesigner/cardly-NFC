import "./globals.css";

export const metadata = {
  title: "Cardly NFC | 25 zwarte NFC kaartjes voor €39,99",
  description: "Bestel 25 premium zwarte NFC kaartjes voor €39,99.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="nl">
      <body>{children}</body>
    </html>
  );
}
