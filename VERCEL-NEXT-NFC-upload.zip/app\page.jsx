"use client";

import { useMemo, useState } from "react";

const stripePaymentLink = "https://buy.stripe.com/PLAATS-HIER-JE-STRIPE-LINK";
const unitPrice = 39.99;

export default function Home() {
  const [sets, setSets] = useState(1);
  const [toast, setToast] = useState("");
  const total = useMemo(() => new Intl.NumberFormat("nl-BE", {
    style: "currency",
    currency: "EUR",
  }).format(sets * unitPrice), [sets]);

  function buy() {
    if (stripePaymentLink.includes("PLAATS-HIER")) {
      setToast("Stripe is nog niet gekoppeld. Vervang de placeholder in app/page.jsx door je eigen Stripe Payment Link.");
      window.setTimeout(() => setToast(""), 4300);
      return;
    }

    const url = new URL(stripePaymentLink);
    url.searchParams.set("quantity", String(sets));
    window.location.href = url.toString();
  }

  return (
    <>
      <header className="siteHeader">
        <a className="brand" href="#top" aria-label="Cardly NFC">
          <span className="brandMark">N</span>
          <span>Cardly NFC</span>
        </a>
        <nav className="navLinks" aria-label="Navigatie">
          <a href="#pakket">Pakket</a>
          <a href="#kwaliteit">Kwaliteit</a>
          <a href="#werking">Werking</a>
          <a href="#faq">FAQ</a>
        </nav>
        <a className="headerBuy" href="#pakket">Bestel 25 kaarten</a>
      </header>

      <main id="top">
        <section className="hero">
          <div className="heroCopy">
            <span className="eyebrow">25 zwarte NFC kaartjes per set</span>
            <h1>Premium NFC kaartjes die meteen professioneel voelen.</h1>
            <p>Een luxe set van <strong>25 matte zwarte NFC-kaarten</strong> voor ondernemers, teams en events. Laat klanten met een tik je contactgegevens, website, socials of boekingspagina openen.</p>
            <div className="heroBuy">
              <a className="primaryAction" href="#pakket">Bestel 25 kaarten voor €39,99</a>
              <span>Geen abonnement. Stripe-klaar.</span>
            </div>
          </div>

          <div className="heroMedia">
            <img src="/assets/nfc-25-black-cards.png" alt="Set van 25 zwarte blanco NFC kaartjes op een luxe bureau" />
            <div className="heroBadge">
              <strong>25 kaarten</strong>
              <span>€39,99 per volledige set</span>
            </div>
          </div>
        </section>

        <section className="trustRow" aria-label="Belangrijkste voordelen">
          <div><strong>25 stuks</strong><span>per bestelling</span></div>
          <div><strong>Zwart & blanco</strong><span>geen logo op de kaart</span></div>
          <div><strong>NFC-ready</strong><span>voor telefoon-tap</span></div>
          <div><strong>Stripe-ready</strong><span>betaling later koppelen</span></div>
        </section>

        <section className="section split" id="kwaliteit">
          <div className="sectionCopy">
            <span className="kicker">Premium uitstraling</span>
            <h2>Zwarte kaarten, geen afleiding.</h2>
            <p>De kaartjes zijn bewust clean gehouden: zwart, strak en zonder gedrukt logo op de kaart. Dat geeft je klant of team een professionele basis die je later kunt personaliseren via NFC of QR.</p>
          </div>
          <div className="qualityGrid">
            <article><span>01</span><h3>Matte zwarte look</h3><p>Een rustige, zakelijke uitstraling die beter past bij premium services dan gewone papieren visitekaartjes.</p></article>
            <article><span>02</span><h3>Digitale bestemming</h3><p>Koppel de kaart aan je website, contactpagina, Instagram, portfolio, menu of afspraakpagina.</p></article>
            <article><span>03</span><h3>Voor teams</h3><p>Met 25 kaarten heb je genoeg voor medewerkers, events, salons, beurzen of klantenbalies.</p></article>
          </div>
        </section>

        <section className="section filmSection">
          <div className="filmCopy">
            <span className="kicker">Video-look preview</span>
            <h2>Een tap-moment dat klanten begrijpen.</h2>
            <p>Deze bewegende preview bootst een korte productvideo na. Later kun je hier een echte AI-video of productvideo plaatsen.</p>
          </div>
          <div className="productFilm">
            <img src="/assets/nfc-phone-tap.png" alt="Telefoon tapt tegen een zwarte blanco NFC kaart" />
            <div className="scanLine"></div>
            <div className="tapCard" aria-hidden="true"></div>
            <div className="filmCaption"><strong>Tap. Open. Connect.</strong><span>NFC werkt zonder app op de meeste moderne smartphones.</span></div>
          </div>
        </section>

        <section className="section productSection" id="pakket">
          <div className="productGallery">
            <img src="/assets/nfc-25-black-cards.png" alt="25 zwarte NFC kaarten zichtbaar in waaier en stapel" />
          </div>
          <aside className="buyPanel">
            <span className="kicker">Complete set</span>
            <h2>25 zwarte NFC kaartjes</h2>
            <p className="productIntro">Je koopt altijd een volledige set van 25 kaarten. De prijs is dus niet per kaart, maar per set.</p>
            <div className="priceBlock"><strong>€39,99</strong><span>voor 25 kaarten</span></div>
            <div className="included">
              <div><b>Inbegrepen</b><span>25 zwarte blanco NFC-kaarten</span></div>
              <div><b>Prijs per kaart</b><span>ongeveer €1,60</span></div>
              <div><b>Checkout</b><span>klaar om Stripe-link te plaatsen</span></div>
            </div>
            <label className="quantity">
              <span>Aantal sets</span>
              <select value={sets} onChange={(event) => setSets(Number(event.target.value))}>
                <option value="1">1 set = 25 kaarten</option>
                <option value="2">2 sets = 50 kaarten</option>
                <option value="3">3 sets = 75 kaarten</option>
                <option value="4">4 sets = 100 kaarten</option>
              </select>
            </label>
            <div className="totalRow"><span>Totaal</span><strong>{total}</strong></div>
            <button className="primaryAction full" onClick={buy}>Bestel via Stripe</button>
            <p className="stripeNote">Plaats je echte Stripe Payment Link in <code>app/page.jsx</code>.</p>
          </aside>
        </section>

        <section className="section steps" id="werking">
          <div className="sectionCopy"><span className="kicker">Simpel proces</span><h2>Van kaart naar klantcontact.</h2></div>
          <div className="stepGrid">
            <article><span>1</span><h3>Kies je bestemming</h3><p>Gebruik bijvoorbeeld je website, digitaal visitekaartje, contactformulier, Linktree, menu of boekingspagina.</p></article>
            <article><span>2</span><h3>Koppel NFC</h3><p>Schrijf de link naar de NFC-chip of laat dit verwerken door je leverancier of fulfilmentpartner.</p></article>
            <article><span>3</span><h3>Laat klanten tikken</h3><p>De klant houdt de telefoon tegen de kaart en opent meteen je gekozen pagina.</p></article>
          </div>
        </section>

        <section className="section faq" id="faq">
          <div className="sectionCopy"><span className="kicker">Duidelijk voor verkoop</span><h2>Veelgestelde vragen.</h2></div>
          <div className="faqList">
            <details open><summary>Krijg ik echt 25 kaarten?</summary><p>Ja. Een bestelling is een set van 25 zwarte NFC-kaartjes voor €39,99.</p></details>
            <details><summary>Staat er een logo op de kaart?</summary><p>Nee. De kaartjes worden gepresenteerd als zwarte blanco kaarten zonder logo op de kaart.</p></details>
            <details><summary>Kan ik Stripe verbinden?</summary><p>Ja. Vervang de placeholder in <code>app/page.jsx</code> door je echte Stripe Payment Link.</p></details>
            <details><summary>Wat moet nog voor live verkoop?</summary><p>Voeg je echte levertermijn, retourbeleid, privacybeleid, contactgegevens en betaalprovider toe voordat je advertenties draait.</p></details>
          </div>
        </section>
      </main>

      <footer><span>© 2026 Cardly NFC</span><span>25 zwarte NFC kaartjes voor €39,99</span></footer>
      <div className={`toast ${toast ? "show" : ""}`} role="status" aria-live="polite">{toast}</div>
    </>
  );
}
